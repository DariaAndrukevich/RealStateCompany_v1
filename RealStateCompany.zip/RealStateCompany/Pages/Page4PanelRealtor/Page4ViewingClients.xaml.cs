﻿using RealStateCompany.Pages;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для Page4ViewingClients.xaml
    /// </summary>
    public partial class Page4ViewingClients : Page
    {
        RealEstateEntity watchClient = new RealEstateEntity();
        public Page4ViewingClients()
        {
            InitializeComponent();
            watchClient.Clients.Load();
            watchClient.TypeClients.Load();
            LoadData();
        }
        private void LoadData()
        {
            var clients = from u in watchClient.Clients
                          join i in watchClient.TypeClients
                          on u.TypeClient equals i.TypeClientCode                          
                          select new
                          {
                              u.ClientCode,
                              u.ClientSurname,
                              u.ClientName,
                              u.ClientPatronymic,
                              u.MobilePhone,
                              u.blackList,
                              i.TypeName, 
                              u.Cause
                          };
            listViewClients.ItemsSource = clients.ToList();
        }
        private void AddNewClients(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4AddNewClient());
        }

        //Поиск клиента по таблице
        private void ShearchInClient(object sender, TextChangedEventArgs e)
        {
            var shearch = from u in watchClient.Clients
                          join i in watchClient.TypeClients
                          on u.TypeClient equals i.TypeClientCode
                          where ((u.ClientSurname.Contains(ShearchInClients.Text)) ||
                          (u.ClientName.Contains(ShearchInClients.Text)) ||
                          (u.ClientPatronymic.Contains(ShearchInClients.Text)) ||
                          (u.MobilePhone.Contains(ShearchInClients.Text)) || 
                          (i.TypeName.Contains(ShearchInClients.Text)))
                          select new
                          {
                              u.MobilePhone,
                              u.ClientName,
                              u.ClientSurname,
                              u.ClientPatronymic,
                              i.TypeName,
                              u.ClientCode,
                              u.blackList,
                              u.Cause
                          };
            if (shearch == null)
            {
                listViewClients.Visibility = Visibility.Hidden;                              
            }
            else  listViewClients.ItemsSource = shearch.ToList();
        }

        private void WhiteList_Unchecked(object sender, RoutedEventArgs e)
        {           
            LoadData();                
        }

        private void WhiteList_Checked(object sender, RoutedEventArgs e)
        {
            //var shearch = watchClient.Clients
            //              .Where(u => u.blackList == false)
            //              select new
            //              {
            //                  u.MobilePhone,
            //                  u.ClientName,
            //                  u.ClientSurname,
            //                  u.ClientPatronymic,
            //                  i.TypeName,
            //                  u.ClientCode,
            //                  u.blackList,
            //                  u.Cause
            //              };
            //listViewClients.ItemsSource = shearch.ToList();
        }

        private void BlackList_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void BlackList_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
