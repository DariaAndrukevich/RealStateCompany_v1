﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealStateCompany.Pages.Page4PanelRealtor
{
    /// <summary>
    /// Логика взаимодействия для Win4TypeApartments.xaml
    /// </summary>
    public partial class Win4TypeApartments : Window
    {
        RealEstateEntity typeApartmentData = new RealEstateEntity();
        public Win4TypeApartments()
        {
            InitializeComponent();
            typeApartmentData.TypeApartment.Load();
            LoadData();
        }
        //Вывод отсортированного списка
        private void LoadData()
        {
            var typeApartments = typeApartmentData.TypeApartment
                                .OrderBy(u => u.ApartmentTypeCode);
            listViewTypeApartment.ItemsSource = typeApartments.ToList();
        }
        private void AddNewTypeApartments(object sender, RoutedEventArgs e)
        {
           TypeApartment newType = new TypeApartment()
           {
                NameApartmentType = NewTypeName.Text
           };
            if (NewTypeName.Text == "")
            {
                MessageBox.Show("Поле добавления не может быть пустым!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
           var repeatRow = typeApartmentData.TypeApartment.Where(u => u.NameApartmentType == NewTypeName.Text).FirstOrDefault();
            if (repeatRow == null)
            {
                try
                {
                    typeApartmentData.TypeApartment.Add(newType);
                    typeApartmentData.SaveChanges();
                }
                catch
                {
                    MessageBox.Show("Ошибка сохранения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Такая запись уже существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
