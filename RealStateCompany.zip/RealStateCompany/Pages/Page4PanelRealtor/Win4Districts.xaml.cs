﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealStateCompany.Pages.Page4PanelRealtor
{
    /// <summary>
    /// Логика взаимодействия для Win4Districts.xaml
    /// </summary>
    public partial class Win4Districts : Window
    {
        RealEstateEntity districtData = new RealEstateEntity();
        public Win4Districts()
        {
            InitializeComponent();
            districtData.Districts.Load();
            listViewDistricts.ItemsSource = districtData.Districts.Local.ToBindingList();
        }

        private void addNewDistrict_Click(object sender, RoutedEventArgs e)
        {
            Districts newDistrict = new Districts()
            {
                DistrictName = NewDistrictName.Text
            };
            if (NewDistrictName.Text == null)
            {
                MessageBox.Show("Поле добавления не может быть пустым!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                try
                {
                    districtData.Districts.Add(newDistrict);
                    districtData.SaveChanges();
                }
                catch
                {
                    MessageBox.Show("Ошибка сохранения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
