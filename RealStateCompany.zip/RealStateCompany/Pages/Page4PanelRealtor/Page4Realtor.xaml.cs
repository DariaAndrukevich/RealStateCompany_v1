﻿using RealStateCompany.Pages;
using RealStateCompany.Pages.Page4PanelRealtor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для Page4Realtor.xaml
    /// </summary>
    public partial class Page4Realtor : Page
    {        
        public Page4Realtor()
        {
            InitializeComponent();
        }
        //Навигация по блоку панели Риэлтора 
        private void ViewingClient_Click(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4ViewingClients());
        }

        private void ViewingRealState_Click(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4ViewingRealState());
        }

        private void AddNewClient_Click(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4AddNewClient());
        }

        private void AddNewRealState_Click(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4AddNewRealState());
        }

        private void ViewingAndCreateContract_Click(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4ViewingAndCreateContract());
        }

        private void ViewingTypeApartment_Click(object sender, RoutedEventArgs e)
        {
            Win4TypeApartments win4TypeApartments = new Win4TypeApartments();
            win4TypeApartments.ShowDialog();
        }

        private void ViewingTypeHouse_Click(object sender, RoutedEventArgs e)
        {
            Win4TypeHouses win4TypeHouses = new Win4TypeHouses();
            win4TypeHouses.ShowDialog();
        }
    }
}
