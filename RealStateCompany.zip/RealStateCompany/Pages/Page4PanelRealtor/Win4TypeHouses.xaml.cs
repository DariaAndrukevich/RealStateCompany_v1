﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealStateCompany.Pages.Page4PanelRealtor
{
    /// <summary>
    /// Логика взаимодействия для Win4TypeHouses.xaml
    /// </summary>
    public partial class Win4TypeHouses : Window
    {
        RealEstateEntity typeHouses = new RealEstateEntity();
        public Win4TypeHouses()
        {
            InitializeComponent();
            typeHouses.TypeHouse.Load();
            LoadData();
           
        }
        private void LoadData()
        {
            var typeHouse = typeHouses.TypeHouse
                                .OrderBy(u => u.idTypeHouse);
            listViewTypeHouse.ItemsSource = typeHouse.ToList();
        }
        // Добавление нового типа постройки
        private void AddNewTypeHouse(object sender, RoutedEventArgs e)
        {
            TypeHouse newType = new TypeHouse()
            {
                TypeHouse1 = NewTypeName.Text
            };
            if (NewTypeName.Text == "")
            {
                MessageBox.Show("Поле добавления не может быть пустым!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            var repeatRow = typeHouses.TypeHouse.Where(u => u.TypeHouse1== NewTypeName.Text).FirstOrDefault();
            if (repeatRow == null)
            {
                try
                {
                    typeHouses.TypeHouse.Add(newType);
                    typeHouses.SaveChanges();
                }
                catch
                {
                    MessageBox.Show("Ошибка сохранения введенного значения.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Такая запись уже существует.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
           
        }
    }
}
