﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page4AddNewClient.xaml
    /// </summary>
    public partial class Page4AddNewClient : Page
    {
        RealEstateEntity clientData = new RealEstateEntity();
        public Page4AddNewClient()
        {
            InitializeComponent();
            clientData.Clients.Load();
            clientData.TypeClients.Load();
            TypeClientCB.ItemsSource = clientData.TypeClients.Local.ToBindingList();
        }

        private void AddNewClient_Click(object sender, RoutedEventArgs e)
        {
            Clients newClient = new Clients()
            {
                TypeClient = TypeClientCB.SelectedIndex,
                ClientSurname = clientSurename.Text,
                ClientName = clientName.Text,
                ClientPatronymic = clientPatronymic.Text,
                PassportData = passportData.Text,
                RegistrationAddress = registrationAdress.Text,
                MobilePhone = phoneCall.Text,
                Email = email.Text
            };
            if (clientSurename.Text == null || clientName.Text == null || clientPatronymic.Text == null || passportData.Text == null ||
                phoneCall.Text == null || Convert.ToString(registrationAdress.Text) == null)
            {
                MessageBox.Show("Вы ввели не все обязательные данные.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
            }
            // Проверка на наличие в базе данных клиента с такими же паспортными данными
            var passport = clientData.Clients.FirstOrDefault(users => users.PassportData == passportData.Text);
            if (passport == null)
            {
                try
                {
                    clientData.Clients.Add(newClient);
                    clientData.SaveChanges();
                    MessageBox.Show("Успешное добавление клиента.", "Сообщение!", MessageBoxButton.OK, MessageBoxImage.Information);
                    TypeClientCB.SelectedIndex = -1;
                    clientSurename.Clear();
                    clientName.Clear();
                    clientPatronymic.Clear();
                    passportData.Clear();
                    registrationAdress.Clear();
                    phoneCall.Clear();
                    email.Clear();
                }
                catch
                {
                    MessageBox.Show("Ошибка добавления клиента.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {                
               MessageBox.Show("Ошибка добавления клиента.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);                
            }
        }
    }
}
