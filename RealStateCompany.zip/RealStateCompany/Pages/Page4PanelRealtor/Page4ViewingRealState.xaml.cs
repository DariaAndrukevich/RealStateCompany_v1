﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page4ViewingRealState.xaml
    /// </summary>
    public partial class Page4ViewingRealState : Page
    {
        RealEstateEntity apartmentData = new RealEstateEntity();
        public Page4ViewingRealState()
        {
            InitializeComponent();
            apartmentData.ApartmentOffer.Load();
            dataList.ItemsSource = apartmentData.ApartmentOffer.Local.ToBindingList();
            
        }        
        private void DeleteChoiseRow(object sender, RoutedEventArgs e)
        {
            var removeRow = dataList.SelectedItem as ApartmentOffer;
            if (removeRow == null)
            {
                MessageBox.Show("Запись для удаления не выбрана. Пожалуйста, выберите запись.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }   
            else
            {
              
            }
        }

        private void ShearchInData(object sender, TextChangedEventArgs e)
        {
            var shearch = from u in apartmentData.ApartmentOffer
                         where ((u.ApartmentCode.ToString().Contains(Shearch.Text)) ||
                         (u.TypeTransaction.Contains(Shearch.Text)) ||
                         (u.ApartmentTypeCode.Contains(Shearch.Text)) ||
                         (u.ApartmentHouseType.Contains(Shearch.Text)) ||
                         (u.ApartmentArea.ToString().Contains(Shearch.Text)) ||
                         (u.NumberOfRooms.ToString().Contains(Shearch.Text)) ||
                         (u.ApartmentRegion.Contains(Shearch.Text)) ||
                         (u.ApartmentDistrict.Contains(Shearch.Text)) ||
                         (u.ApartmentStreetandNumHome.Contains(Shearch.Text)) ||
                         (u.ApartmentCostFrom.ToString().Contains(Shearch.Text)) ||
                         (u.AdditionalInformation.Contains(Shearch.Text)) ||
                         (u.PaymentType.Contains(Shearch.Text)))                         
                         select new
                         {
                             u.ApartmentCode,
                             u.TypeTransaction,
                             u.ApartmentTypeCode,
                             u.ApartmentHouseType,
                             u.ApartmentArea,
                             u.NumberOfRooms,
                             u.ApartmentRegion,
                             u.ApartmentDistrict,
                             u.ApartmentSellerCode,
                             u.ApartmentStreetandNumHome,                           
                             u.ApartmentCostFrom,
                             u.AdditionalInformation,
                             u.Relevance,
                             u.ApartmentPhoto,
                             u.Garage,
                             u.PaymentType
                         };
            dataList.ItemsSource = shearch.ToList();
        }

        private void AddNewRealState(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4AddNewRealState());
        }

        private void EditRow_Click(object sender, RoutedEventArgs e)
        {

        }

        private void WatchRow_Click(object sender, RoutedEventArgs e)
        {
            var watchRow = dataList.SelectedItem as ApartmentOffer;
            if (watchRow == null)
            {
                MessageBox.Show("Запись для просмотра не выбрана. Пожалуйста, выберите запись.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            else
            {
                NavigationClass.navigationProgramm.Navigate(new Page3WatchElement(watchRow));
            }
        }
    }
}
