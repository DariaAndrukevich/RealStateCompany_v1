﻿using RealStateCompany.Classes;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RealStateCompany.Pages;
using RealStateCompany.Pages.Page4PanelRealtor;

namespace RealStateCompany.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page4AddNewRealState.xaml
    /// </summary>
    public partial class Page4AddNewRealState : Page
    {
        RealEstateEntity apartmentData = new RealEstateEntity();
        public Page4AddNewRealState()
        {
            InitializeComponent();
            apartmentData.ApartmentOffer.Load();
            apartmentData.Districts.Load();
            apartmentData.Clients.Load();
            apartmentData.TypeApartment.Load();
            apartmentData.TypeOfTransaction.Load();
            apartmentData.TypeHouse.Load();
        }

        // Добавление фотографий в лист и конвертация в формат Image для дальнейшего добавления в базу данных
        private void AddPhoto(object sender, RoutedEventArgs e)
        {
            string[] fileNames = FileLoader.Fileload();
            BitmapImage[] images = new BitmapImage[10];
            for (int i = 0; i < fileNames.Length; i++)
            {
                images[i] = new BitmapImage(new Uri(fileNames[i]));
            }
            addedPhoto.ItemsSource = fileNames; // Вывод в лист для отображения фотографий выбранных для загрузки  
        }

        private void AddNewApartment_Click(object sender, RoutedEventArgs e)
        {
            ApartmentOffer apartment = new ApartmentOffer()
            {
                TypeTransaction = typeTransaction.Text,
                ApartmentTypeCode = typeApartment.Text,
                ApartmentHouseType = typeHouse.Text,
                ApartmentArea = Convert.ToInt32(apartmentArea.Text),
                NumberOfRooms = Convert.ToInt16(numberOfHouse.Text),
                ApartmentRegion = apartmentCityAndRegion.Text,
                ApartmentDistrict = apartmentDistrict.Text,
                ApartmentStreetandNumHome = apartmentAdress.Text,
                FloorsInTheHouse = Convert.ToInt32(apartmentFloorInHouse.Text),
                ApartamentFloor = Convert.ToInt32(apartmentFloor.Text),
                Garage = Convert.ToBoolean(garage),
                ApartmentCostFrom = Convert.ToInt32(apartmentCost.Text),
                ApartmentSellerCode = Convert.ToInt32(sellerCode.Text)
            };
            var district = apartmentData.Districts.Where(u => u.DistrictName == apartmentDistrict.Text).FirstOrDefault();
            var clientSeller = apartmentData.Clients.Where(u => Convert.ToString(u.ClientCode) == sellerCode.Text).FirstOrDefault();
            var typeApartments = apartmentData.TypeApartment.Where(u => u.NameApartmentType == typeApartment.Text).FirstOrDefault();
            var typeHouses = apartmentData.TypeHouse.Where(u => u.TypeHouse1 == typeHouse.Text).FirstOrDefault();
            bool checkingTA = CheckingClass.CheckTypeApartment(typeApartments);
            bool checkingD = CheckingClass.CheckDistrict(district);
            bool checkingCS = CheckingClass.CheckCodeClient(clientSeller);
            bool checkingTH = CheckingClass.CheckCodeClient(typeHouses);
            if (checkingTA == true && checkingD == true && checkingCS == true && checkingTH == true)
            {
                try
                {
                    apartmentData.ApartmentOffer.Add(apartment);
                    apartmentData.SaveChanges();
                    MessageBox.Show("Добавление прошло успешно.", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Произошла ошибка на стороне сервера. Сохранение не возможно.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }            
        }    

        // В случае, если код клиента неизвестен, или пользователь системы не знает/не помнит код
        private void IDontCodeClient(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page4ViewingClients());            
        }
    }
}
