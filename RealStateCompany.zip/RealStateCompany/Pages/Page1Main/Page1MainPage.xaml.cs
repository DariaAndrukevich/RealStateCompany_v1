﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для Page1MainPage.xaml
    /// </summary>
    public partial class Page1MainPage : Page
    {
        public Page1MainPage()
        {
            InitializeComponent();
        }

        private void logInPage(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page2AutoPageChoise());
        }

        
        private void GuestPage(object sender, RoutedEventArgs e)
        {
            NavigationClass.navigationProgramm.Navigate(new Page3Guest());
        }
    }
}
