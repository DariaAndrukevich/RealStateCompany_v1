﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для Page3Guest.xaml
    /// </summary>
    public partial class Page3Guest : Page
    {
        RealEstateEntity apartmentData = new RealEstateEntity();
        public Page3Guest()
        {
            InitializeComponent();
            WatchApartment();
        }       
        //Вывод всей недвижимости из базы данных с ключевой информацией    
        void WatchApartment()
        {
               var apartmentOutput = from u in apartmentData.ApartmentOffer
                                     .Where(u => u.Relevance == true)
                                     select new
                                     {
                                         u.ApartmentCode,
                                         u.TypeTransaction,
                                         u.ApartmentTypeCode,
                                         u.ApartmentHouseType,
                                         u.ApartmentArea,
                                         u.NumberOfRooms,
                                         u.ApartmentRegion,
                                         u.ApartmentDistrict,
                                         u.ApartmentSellerCode,
                                         u.ApartmentStreetandNumHome,
                                         u.ApartmentPhoto,
                                         u.ApartmentCostFrom,
                                         u.AdditionalInformation,
                                         u.Relevance,
                                         u.Garage,
                                         u.PaymentType
                                     };            
            dataList.ItemsSource = apartmentOutput.ToList();            
        }
        //Вывод выбранного эллемента на новую страницу с более подробной информацией
        private void WatchChoiseElement(object sender, SelectionChangedEventArgs e)
        {          
            ApartmentOffer p = (ApartmentOffer)dataList.SelectedItem;            
            NavigationClass.navigationProgramm.Navigate(new Page3WatchElement(p));            
        }        
    }
}
