﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для WatchPhoto.xaml
    /// </summary>
    public partial class WatchPhoto : Window
    {
        public WatchPhoto(ApartmentPhoto watch)
        {
            InitializeComponent();
            byteToImage(watch);
        }
        // Конвертация байтового массива изображения в ресурс компонента Image для просмотра
        void byteToImage(ApartmentPhoto watch)
        {
            byte[] byteArr = watch.img;
            using (MemoryStream stream = new MemoryStream(byteArr))
            {
                image.Source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            }
        }
        private void closedWindowPhoto(object sender, RoutedEventArgs e)
        {
            Close();        
        }
    }
}
