﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для Page3WatchElement.xaml
    /// </summary>
    public partial class Page3WatchElement : Page
    {
        RealEstateEntity apartmentData = new RealEstateEntity();       

        public Page3WatchElement(ApartmentOffer p)
        {
            InitializeComponent();
            apartmentData.ApartmentOffer.Load();
            apartmentData.ApartmentPhoto.Load();
            WatchInfo(p);
        }
        //Запрос на вывод информации о выбранном элементе
       void WatchInfo(ApartmentOffer p) 
        {
            nameApartmentType.Text = p.ApartmentTypeCode;
            numberOfRooms.Text = Convert.ToString(p.NumberOfRooms);
            apartmentArea.Text = Convert.ToString(p.ApartmentArea);
            apartmentDistrict.Text = p.ApartmentDistrict;
            apartmentAddress.Text = p.ApartmentStreetandNumHome;
            apartmentCost.Text = Convert.ToString(p.ApartmentCostFrom);
            additionalInformation.Text = p.AdditionalInformation;
            apartmentHouseType.Text = p.ApartmentHouseType;
            apartmentRegion.Text = p.ApartmentRegion;
            paymentType.Text = p.PaymentType;
            apartmentAllArea.Text = Convert.ToString(p.ApartmentArea);
            apartmentFloor.Text = Convert.ToString(p.ApartamentFloor);
            floorsInHouse.Text = Convert.ToString(p.FloorsInTheHouse);
            quantityRoom.Text = Convert.ToString(p.NumberOfRooms);
            var photo = apartmentData.ApartmentPhoto
                .Where(i => i.ApartmentCode == p.ApartmentCode);
            checkPhoto.ItemsSource = photo.ToList();
        }
       
        // Передача выбранной картинки в новое окно для более крупного просмотра 
        private void CheckPhoto(object sender, SelectionChangedEventArgs e)
        {
            var watch = checkPhoto.SelectedItem as ApartmentPhoto;
            new WatchPhoto(watch).ShowDialog();
        }
    }
}
