﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime;
using System.Data.Entity;
using RealStateCompany.Pages;

namespace RealStateCompany
{
    /// <summary>
    /// Логика взаимодействия для Page2AutoPageChoise.xaml
    /// </summary>
    public partial class Page2AutoPageChoise : Page
    {
        RealEstateEntity apartmentData = new RealEstateEntity();
        int i = 0;
        public Page2AutoPageChoise()
        {
            InitializeComponent();
            apartmentData.Employees.Load();
        }     
        // Авторизация пользователя 
        private async void loginCheking(object sender, RoutedEventArgs e)
        {            
            if (loginAuto.Text.Length > 0) // Проверка - введен ли логин  
            {
                if (passAuto.Password.Length > 0) // Проверка - введен ли пароль         
                {                    
                    // Проверка наличия записи в базе
                    var user = apartmentData.Employees.Where(u => u.loginSystem == loginAuto.Text & u.passwordSystem == passAuto.Password).FirstOrDefault();
                    if (user == null) 
                    {                       
                        i++;
                        qTry.Visibility = Visibility.Visible;
                        if (i == 1)
                        {
                            MessageBox.Show("Пользователь не найден либо введенные логин или пароль не верны. Повторите ввод.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                            qTry.Text = "Осталось " + (i + 1) + " попытки.";
                        }
                        if (i == 2)
                        {
                            MessageBox.Show("Пользователь не найден либо введенные логин или пароль не верны. Повторите ввод.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                            qTry.Text = "Осталась " + (i - 1) + " попытка.";
                        }
                        if (i == 3)
                        {
                            // Блокировка кнопки и сообщение о 3 неудачных попытках ввода                              
                            loginCheck.Visibility = Visibility.Hidden;
                            qTry.Visibility = Visibility.Hidden;
                            MessageBox.Show("Ваш ввод был не верен 3 раза. Пожалуйста, дождитесь повторного открытия формы.", "Ошибка авторизации!", MessageBoxButton.OK, MessageBoxImage.Error);
                            await Task.Run(() => Await());
                            MessageBox.Show("Спасибо за ожидание. Пожалуйста, повторите ввод заново.","Сообщение!", MessageBoxButton.OK, MessageBoxImage.Information);                           
                            i = 0;
                            loginAuto.Clear();
                            passAuto.Clear();
                            loginCheck.Visibility = Visibility.Visible;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Добро пожаловать!");
                        loginAuto.Clear();
                        passAuto.Clear();
                        WindowUsers(user);
                    }
                }
                else
                {
                    MessageBox.Show("Поле пароля не может быть пустым. Введите пароль.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Поле логина не может быть пустым. Введите логин.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        public void Await() // Метод для блокировки панели авторизации после 3 попыток ошибочного ввода пароля. 
        {           
            Thread.Sleep(5000);           
        }

        // Открытие определенных страниц и данных, доступных для определеных ролей
        private static void WindowUsers(Employees user)
        {
            switch (user.RoleCode)
            {
                case 1: // Страница работы риэтора
                    NavigationClass.navigationProgramm.Navigate(new Page4Realtor());
                    break;
                case 2: // Страница работы кадровика
                    NavigationClass.navigationProgramm.Navigate(new Page5PersonnelDepartament());
                    break;
                case 3: // Страница работы администратора системы
                    NavigationClass.navigationProgramm.Navigate(new Page6SystemAdmin());
                    break;
                case 4: // Страница работы директора 
                    NavigationClass.navigationProgramm.Navigate(new Page7Director());
                    break;                
            }
        }
    }
}
