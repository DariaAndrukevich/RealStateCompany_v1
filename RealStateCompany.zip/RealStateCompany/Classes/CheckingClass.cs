﻿using RealStateCompany.Pages;
using RealStateCompany.Pages.Page4PanelRealtor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RealStateCompany.Classes
{
    class CheckingClass
        // Класс с методами для вывода сообщений в случае не найденной записи. 
    {
        public static bool CheckCodeClient(Clients clientSeller)
        {
            // Проверка на наличие клиента продавца в базе данных                     
            if (clientSeller == null)
            {
                MessageBoxResult result = new MessageBoxResult();
                result = MessageBox.Show("Клиент продавец с таким кодом не найден. Хотите добавить нового клиента?", "Ошибка!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        NavigationClass.navigationProgramm.Navigate(new Page4AddNewClient());
                        break;
                    case MessageBoxResult.No:
                        MessageBox.Show("К сожалению, вы не сможете продолжить оформление недвижимости на продажу.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }
                return false;
            }
            else return true;
        }
        public static bool CheckDistrict(Districts district)
        {
            //Проверка на наличие записи о районе в базе данных 
            if (district == null)
            {
                MessageBoxResult result = new MessageBoxResult();
                result = MessageBox.Show("Такой район не найден. Хотите посмотреть список районов?", "Ошибка!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        Win4Districts openDistricts = new Win4Districts();
                        openDistricts.ShowDialog();
                        break;
                    case MessageBoxResult.No:
                        MessageBox.Show("К сожалению, вы не сможете продолжить оформление недвижимости на продажу.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }
                return false;
            }
            else return true;
        }

        public static bool CheckTypeApartment(TypeApartment typeApartments)
        {
            //Проверка на наличие введенного района в базе данных 
            if (typeApartments == null)
            {
                MessageBoxResult result = new MessageBoxResult();
                result = MessageBox.Show("Такой тип недвижимости не найден. Хотите посмотреть список типов недвижимости?", "Ошибка!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        Win4TypeApartments openTypeApartments = new Win4TypeApartments();
                        openTypeApartments.ShowDialog();
                        break;
                    case MessageBoxResult.No:
                        MessageBox.Show("К сожалению, вы не сможете продолжить оформление недвижимости на продажу.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }
                return false;
            }
            else return true;
        }
        public static bool CheckCodeClient(TypeHouse typeHouses)
        {
            // Проверка на наличие типа постройки в базе данных                     
            if (typeHouses == null)
            {
                MessageBoxResult result = new MessageBoxResult();
                result = MessageBox.Show("Введенный вами тип строения не найден. Хотите посмотреть список типов строения или добавить новый?", "Ошибка!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        NavigationClass.navigationProgramm.Navigate(new Win4TypeHouses());
                        break;
                    case MessageBoxResult.No:
                        MessageBox.Show("К сожалению, вы не сможете продолжить оформление недвижимости на продажу.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }
                return false;
            }
            else return true;
        }
    }
}
