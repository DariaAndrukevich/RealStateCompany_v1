﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealStateCompany.Classes
{
    class FileLoader
    {
        public static string fileName;
        public static string[] fileNames;
        public static string[] Fileload()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image(JPG,PNG)|*.JPG;*.PNG;|All files (ALL)|*.*";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileNames = openFileDialog.FileNames;
                return fileNames;
            }
            else return null;
        }
        public static string Fileloaded()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image(JPG,PNG)|*.JPG;*.PNG;|All files (ALL)|*.*";
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = openFileDialog.FileName;
                return fileName;
            }
            else return null;
        }
    }
}
