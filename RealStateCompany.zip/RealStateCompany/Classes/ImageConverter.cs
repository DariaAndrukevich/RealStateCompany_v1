﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace RealStateCompany.Classes
{
    class ImageConverter
    {
        public static byte[] ConvertToByte(string fileNames)
        {
            if (fileNames != "")
            {
                Image image = Image.FromFile(fileNames);

                byte[] imageToDB;
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    image.Save(memoryStream, ImageFormat.Png);

                    imageToDB = memoryStream.ToArray();
                }
                return imageToDB;
            }
            else return null;
        }
    }
}
